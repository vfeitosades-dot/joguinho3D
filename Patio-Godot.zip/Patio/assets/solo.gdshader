shader_type spatial;
render_mode specular_disabled;
varying vec2 patio;
void vertex(){ patio=(MODEL_MATRIX*vec4(VERTEX,1.)).xz; }
float noise2(vec2 p){
	vec2 i=floor(p), f=fract(p); f=f*f*(3.-2.*f);
	vec4 n=fract(sin(vec4(dot(i,vec2(17.1,69.5)))+vec4(0.,17.1,69.5,86.6))*43758.54);
	return mix(mix(n.x,n.y,f.x),mix(n.z,n.w,f.x),f.y);
}
float stroke(float d,float w,float aa){return 1.-smoothstep(w,w+aa,abs(d));}
void fragment(){
	vec2 p=patio; float aa=clamp(length(fwidth(p))*0.55,0.002,0.4);
	float grain=noise2(p*81.)*exp(-aa*12.) + noise2(p*4.)*0.8 + noise2(p*.21)*1.2;
	vec3 concrete=vec3(.45,.475,.455)+(grain-1.5)*.024;
	vec2 seam=3.-abs(mod(p+3.,6.)-3.);
	float joint=stroke(min(seam.x,seam.y),.009,aa)*exp(-aa*4.);
	concrete*=1.-.19*joint;
	float circle=length(p-vec2(0.,2.));
	float land=length(p);
	float paint=stroke(circle-7.,.055,aa) + stroke(circle-6.62,.018,aa);
	float lane=stroke(abs(p.x)-2.6,.075,aa)*step(p.y,-4.);
	float dashes=stroke(p.x,.048,aa)*step(mod(-p.y,4.),1.9)*step(p.y,-6.);
	float hashmarks=stroke(mod(-p.y+.045,5.)-.045,.047,aa)*step(2.62,abs(p.x))*step(abs(p.x),3.25)*step(p.y,-4.);
	concrete=mix(concrete,vec3(.94,.90,.75),clamp(paint+lane+dashes+hashmarks,0.,1.)*(.83+.09*grain));
	float orange=stroke(circle-7.4,.134,aa)*step(.83,abs(normalize(p-vec2(0.,2.)+vec2(.0001)).x));
	orange+=stroke(land-79.15,.095,aa);
	concrete=mix(concrete,vec3(.86,.31,.105),clamp(orange,0.,1.)*.89);
	vec3 sand=vec3(.51,.49,.39)+(grain-1.5)*.04;
	ALBEDO=mix(concrete,sand,smoothstep(80.,80.1,land)); ROUGHNESS=.97;
}
