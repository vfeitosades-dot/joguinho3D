extends Node3D

func _ready() -> void:
	var ambiente := Environment.new()
	ambiente.background_mode = Environment.BG_SKY
	var ceu := ProceduralSkyMaterial.new()
	ceu.sky_top_color = Color("#5493ad")
	ceu.sky_horizon_color = Color("#e5dfc5")
	ceu.sky_curve = 0.19
	ceu.ground_horizon_color = ceu.sky_horizon_color
	ceu.sun_angle_max = 7.0
	var sky := Sky.new()
	sky.sky_material = ceu
	ambiente.sky = sky
	ambiente.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	ambiente.ambient_light_color = Color("#e6edf2")
	ambiente.ambient_light_energy = 0.58
	ambiente.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
	ambiente.fog_enabled = true
	ambiente.fog_light_color = Color("#e6dfcb")
	ambiente.fog_density = 0.0026
	ambiente.fog_sky_affect = 0.08
	var mundo := WorldEnvironment.new()
	mundo.environment = ambiente
	add_child(mundo)
	var sol := DirectionalLight3D.new()
	sol.rotation_degrees = Vector3(-35, -53, 0)
	sol.light_color = Color("#fff2d9")
	sol.light_energy = 1.1
	sol.shadow_enabled = true
	sol.shadow_bias = 0.035
	sol.directional_shadow_max_distance = 62
	add_child(sol)
	var piso := StaticBody3D.new()
	piso.name = "Solo"
	var forma := CollisionShape3D.new()
	var volume := BoxShape3D.new()
	volume.size = Vector3(1200, 1, 1200)
	forma.position.y = -0.5
	forma.shape = volume
	piso.add_child(forma)
	var chao := MeshInstance3D.new()
	var plano := PlaneMesh.new()
	plano.size = Vector2(1200,1200)
	chao.mesh = plano
	var material := ShaderMaterial.new()
	material.shader = preload("res://assets/solo.gdshader")
	chao.material_override = material
	piso.add_child(chao)
	add_child(piso)
	serra(340.0, 67.0, 39, Color("#9caeaa"))
	serra(246.0, 39.0, 67, Color("#919c92"))
	serra(164.0, 21.0, 12, Color("#a49c83"))

# Anéis de relevo ficam além da área plana de movimento.
func serra(raio: float, altura: float, semente: int, cor: Color) -> void:
	var ruido := FastNoiseLite.new()
	ruido.seed = semente
	ruido.frequency = 0.012
	ruido.fractal_octaves = 3
	var malha := SurfaceTool.new()
	malha.begin(Mesh.PRIMITIVE_TRIANGLES)
	var aneis: Array[PackedVector3Array] = []
	var total := 148
	for j in 4:
		var anel := PackedVector3Array()
		for i in total:
			var ang := TAU * float(i) / total
			var radial := Vector2(sin(ang),cos(ang))
			var p := radial * raio
			var n := ruido.get_noise_2dv(p)
			var r: float = raio + [-31.0,-6.0,11.0,43.0][j] + 7.0*n
			var pico := maxf(0.08,0.55+0.68*n+0.21*sin(3.0*ang+semente))
			var y: float = [-3.0, altura*pico*0.50, altura*pico, -4.0][j]
			anel.push_back(Vector3(radial.x*r,y,radial.y*r))
		aneis.append(anel)
	var base := cor.srgb_to_linear()
	for j in 3:
		for i in total:
			var k := (i+1)%total
			for triangulo in [[aneis[j][i],aneis[j+1][i],aneis[j+1][k]],
					[aneis[j][i],aneis[j+1][k],aneis[j][k]]]:
				var tom := 0.99 + 0.025 * sin(float(i*27+j*71))
				var normal: Vector3 = (triangulo[2]-triangulo[0]).cross(triangulo[1]-triangulo[0]).normalized()
				if normal.y < 0: normal = -normal
				for vertice in triangulo:
					malha.set_color(Color(base.r*tom,base.g*tom,base.b*tom))
					malha.set_normal(normal)
					malha.add_vertex(vertice)
	var tinta := StandardMaterial3D.new()
	tinta.vertex_color_use_as_albedo = true
	tinta.cull_mode = BaseMaterial3D.CULL_DISABLED
	tinta.roughness = 1.0
	malha.set_material(tinta)
	var montanha := MeshInstance3D.new()
	montanha.mesh = malha.commit()
	montanha.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(montanha)
