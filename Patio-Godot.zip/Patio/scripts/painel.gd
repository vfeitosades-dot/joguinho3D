extends Control

const TINTA := Color("#203235ee")
const CLARO := Color("#faf9ee")
const LARANJA := Color("#ff905f")
@onready var personagem = $"../../Personagem"
var fonte: Font = ThemeDB.fallback_font
var forte := FontVariation.new()
var caixa := StyleBoxFlat.new()
var menu := VBoxContainer.new()

func _ready() -> void:
	forte.base_font = fonte
	forte.variation_embolden = 0.55
	caixa.bg_color = TINTA
	caixa.set_corner_radius_all(7)
	add_child(menu)
	menu.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	menu.custom_minimum_size.x = 250
	menu.grow_horizontal = Control.GROW_DIRECTION_BOTH
	menu.grow_vertical = Control.GROW_DIRECTION_BOTH
	menu.add_theme_constant_override("separation",12)
	var titulo := Label.new()
	titulo.text = "Em pausa"
	titulo.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	titulo.add_theme_font_size_override("font_size",38)
	menu.add_child(titulo)
	for nome in ["Continuar","Sair do jogo"]:
		var botao := Button.new()
		botao.text = nome
		botao.custom_minimum_size.y = 48
		botao.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
		for estado in ["normal","hover","pressed"]:
			var estilo := StyleBoxFlat.new()
			estilo.set_corner_radius_all(5)
			estilo.bg_color = Color("#f68c54") if nome == "Continuar" else Color("#47575a")
			if estado != "normal": estilo.bg_color = estilo.bg_color.lightened(0.14)
			botao.add_theme_stylebox_override(estado,estilo)
		if nome == "Continuar":
			for estado in ["font_color","font_hover_color","font_focus_color","font_pressed_color"]:
				botao.add_theme_color_override(estado,Color("#182829"))
			botao.pressed.connect(alternar)
		else:
			botao.pressed.connect(get_tree().quit)
		menu.add_child(botao)
	menu.hide()

func alternar() -> void:
	personagem.pausar(not personagem.pausado)
	menu.visible = personagem.pausado
	if menu.visible: menu.get_child(1).grab_focus()
	queue_redraw()

func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_ESCAPE:
		alternar()
		get_viewport().set_input_as_handled()

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT and is_node_ready() and not personagem.pausado:
		alternar()

func _process(_delta: float) -> void:
	queue_redraw()

func bloco(x: float, y: float, w: float, h: float) -> void:
	draw_style_box(caixa, Rect2(x,y,w,h))

func texto(p: Vector2, s: String, px: int, cor := CLARO, negrito := false) -> void:
	draw_string(forte if negrito else fonte,p,s,HORIZONTAL_ALIGNMENT_LEFT,-1,px,cor)

func _draw() -> void:
	if personagem == null: return
	if personagem.pausado:
		draw_rect(Rect2(Vector2.ZERO,size),Color("#16282de2"))
		return
	bloco(28,26,146,48)
	for i in 3:
		var p := Vector2(42+i*6,55-i*1.8)
		draw_colored_polygon(PackedVector2Array([p,p+Vector2(5,0),p+Vector2(12,-14),p+Vector2(7,-14)]),LARANJA)
	texto(Vector2(82,59),"PÁTIO",24,CLARO,true)
	var y := size.y-68
	bloco(28,y,390,42)
	texto(Vector2(43,y+27),"WASD",15,LARANJA,true)
	texto(Vector2(96,y+27),"Mover",15)
	texto(Vector2(160,y+27),"SHIFT",15,LARANJA,true)
	texto(Vector2(214,y+27),"Correr",15)
	texto(Vector2(277,y+27),"MOUSE",15,LARANJA,true)
	texto(Vector2(340,y+27),"Olhar",15)
	bloco(size.x-143,26,115,37)
	texto(Vector2(size.x-130,51),"ESC",14,LARANJA,true)
	texto(Vector2(size.x-92,51),"Pausa",14)
	var ritmo: String = personagem.ritmo
	var x := size.x-174
	bloco(x,y,146,42)
	for i in 3:
		var aceso: bool = i==0 or (i==1 and ritmo!="Repouso") or ritmo=="Corrida"
		var h := 6.0+i*4.0
		draw_rect(Rect2(x+14+i*6,y+28-h,4,h),LARANJA if aceso else Color("#62716f"))
	texto(Vector2(x+44,y+27),ritmo,15,CLARO,true)
