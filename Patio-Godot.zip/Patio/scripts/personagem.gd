extends CharacterBody3D

const PASSO := 1.71
const CORRIDA := 5.24
const LIMITE := 80.0
@onready var modelo: Node3D = $Manequim
@onready var animador: AnimationPlayer = $Manequim/AnimationPlayer
@onready var camera: Camera3D = $"../Camera"
var rumo := -0.21
var inclinacao := 0.13
var distancia := 4.1
var foco := Vector3.ZERO
var pausado := false
var ritmo := "Repouso"
var velocidade := 0.0
var mistura := AnimationTree.new()
var fase := 0.72
var velocidade_visual := 0.0
var duracao_passo: float
var duracao_corrida: float

func _ready() -> void:
	foco = global_position + Vector3.UP * 1.27
	modelo.rotation.y = PI + rumo
	animador.get_animation_library("").add_animation("Repouso", preload("res://assets/repouso.res"))
	animador.get_animation_library("").add_animation("Caminhada", preload("res://assets/caminhada.res"))
	duracao_passo = animador.get_animation("Caminhada").length
	animador.get_animation_library("").add_animation("Corrida", preload("res://assets/corrida.res"))
	duracao_corrida = animador.get_animation("Corrida").length
	mistura.tree_root = preload("res://assets/locomocao.tres")
	mistura.root_node = ^"../Manequim"
	mistura.anim_player = ^"../Manequim/AnimationPlayer"
	mistura.callback_mode_process = AnimationMixer.ANIMATION_CALLBACK_MODE_PROCESS_MANUAL
	add_child(mistura)
	mistura.active = true
	animar(0.0)
	posicionar_camera(1.0)
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _unhandled_input(event: InputEvent) -> void:
	if pausado:
		return
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		rumo -= event.screen_relative.x * 0.0028
		inclinacao = clampf(inclinacao + event.screen_relative.y * 0.0023, -0.08, 0.96)
	elif event is InputEventMouseButton and event.pressed:
		if event.button_index == MOUSE_BUTTON_WHEEL_UP:
			distancia = maxf(2.8, distancia - 0.45)
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			distancia = minf(6.5, distancia + 0.45)
		elif event.button_index == MOUSE_BUTTON_LEFT:
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func pressionada(tecla: Key, alternativa: Key) -> float:
	return float(Input.is_physical_key_pressed(tecla) or Input.is_physical_key_pressed(alternativa))

func _physics_process(delta: float) -> void:
	if pausado:
		return
	var eixo := Vector2(pressionada(KEY_D, KEY_RIGHT) - pressionada(KEY_A, KEY_LEFT),
			pressionada(KEY_S, KEY_DOWN) - pressionada(KEY_W, KEY_UP)).limit_length()
	var direcao := Vector3(eixo.x, 0, eixo.y).rotated(Vector3.UP, rumo)
	var alvo := direcao * (CORRIDA if Input.is_key_pressed(KEY_SHIFT) else PASSO)
	var plano := Vector3(velocity.x, 0, velocity.z).move_toward(alvo, 13.0 * delta)
	velocity = Vector3(plano.x, velocity.y - 22.0 * delta, plano.z)
	var anterior := Vector2(global_position.x,global_position.z)
	move_and_slide()
	var deslocamento := Vector2(global_position.x, global_position.z)
	if deslocamento.length() > LIMITE:
		var borda := deslocamento.limit_length(LIMITE)
		global_position.x = borda.x
		global_position.z = borda.y
	var real := (Vector2(global_position.x,global_position.z) - anterior) / delta
	velocidade = real.length()
	velocity.x = real.x
	velocity.z = real.y
	if direcao.length_squared() > 0.01:
		modelo.rotation.y = lerp_angle(modelo.rotation.y, atan2(direcao.x, direcao.z), 1.0-exp(-15.0*delta))
	animar(delta)

func animar(delta: float) -> void:
	velocidade_visual = lerpf(velocidade_visual, velocidade, 1.0 - exp(-11.0 * delta))
	var movimento := smoothstep(0.0, PASSO, velocidade_visual)
	var corrida := smoothstep(PASSO, CORRIDA, velocidade_visual)
	# O mesmo ciclo de passada acompanha o pé de apoio durante a troca de ritmo.
	var comprimento := lerpf(PASSO * duracao_passo, CORRIDA * duracao_corrida, corrida)
	fase = fposmod(fase + velocidade_visual * delta / comprimento, 1.0)
	mistura.set("parameters/FasePasso/seek_request", fase * duracao_passo)
	mistura.set("parameters/FaseCorrida/seek_request", fposmod(fase + 0.04, 1.0) * duracao_corrida)
	mistura.set("parameters/Passadas/blend_amount", corrida)
	mistura.set("parameters/Movimento/blend_amount", movimento)
	mistura.advance(delta)
	ritmo = "Repouso" if movimento < 0.035 else ("Corrida" if corrida > 0.5 else "Caminhada")

func _process(delta: float) -> void:
	if not pausado:
		posicionar_camera(1.0-exp(-15.0*delta))

func posicionar_camera(peso: float) -> void:
	foco = foco.lerp(global_position + Vector3.UP * 1.27, peso)
	var orbita := Vector3(0, sin(inclinacao), cos(inclinacao)).rotated(Vector3.UP, rumo)
	camera.global_position = foco + orbita * distancia
	camera.look_at(foco + Vector3.UP * 0.06)

func pausar(estado: bool) -> void:
	pausado = estado
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if pausado else Input.MOUSE_MODE_CAPTURED
